<link href="stylefooter.css" rel="stylesheet" type="text/css"/>
<footer style="border: solid 2px #8A0808;">
    <h6> Games Xperience, 2018 </h6>
</footer>