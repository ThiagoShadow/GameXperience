<link href="styleheader.css" rel="stylesheet" type="text/css"/>
<nav class="navbar navbar-expand-lg navbar-light" style="border: solid 2px #8A0808;">
    <a class="navbar-brand">
        <img src="Imagens/gxp2.png" width="90" height="80" style="margin-right: 30%;">
    </a>
    <button style="background-color: #8A0808;" class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon" ></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <a style="color: #8A0808;" class="nav-item nav-link" href="index.php"> GXP </a>
            <a style="color: #8A0808;" class="nav-item nav-link" href="imagens.php"> Imagens </a>
            <a style="color: #8A0808;" class="nav-item nav-link" href="cadastro.php"> Cadastro </a>
            <a style="color: #8A0808;" class="nav-item nav-link" href="ticket.php"> Tickets </a>
        </div>
    </div>
</nav>